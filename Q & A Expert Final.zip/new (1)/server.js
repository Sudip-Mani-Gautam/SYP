require("dotenv").config()
const express = require("express")
const mysql = require("mysql2/promise")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const multer = require("multer")
const path = require("path")
const cors = require("cors")
const fs = require("fs")

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use("/uploads", express.static("uploads"))

// Update the database connection section to ensure it works with XAMPP MySQL
// Database connection
const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "", // IN my XAMPP password is not set
  database: process.env.DB_NAME || "qa_platform2", // i have used qa_platform2
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Adding database initialization function
async function initializeDatabase() {
  try {
    console.log("Checking database connection and tables...")

    // Create database if it doesn't exist
    await pool.query(`CREATE DATABASE IF NOT EXISTS qa_platform2`)

    // Use the database
    await pool.query(`USE qa_platform2`)

    // Create users table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        profile_picture VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create questions table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        body TEXT NOT NULL,
        topic VARCHAR(50) NOT NULL,
        image_url VARCHAR(255) DEFAULT NULL,
        upvotes INT DEFAULT 0,
        downvotes INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create answers table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS answers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        question_id INT NOT NULL,
        user_id INT NOT NULL,
        body TEXT NOT NULL,
        is_accepted BOOLEAN DEFAULT FALSE,
        upvotes INT DEFAULT 0,
        downvotes INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create comments table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        content_type ENUM('question', 'answer') NOT NULL,
        content_id INT NOT NULL,
        user_id INT NOT NULL,
        body TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create votes table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS votes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        content_type ENUM('question', 'answer') NOT NULL,
        content_id INT NOT NULL,
        vote_type ENUM('upvote', 'downvote') NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_vote (user_id, content_type, content_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    console.log("Database and tables initialized successfully")

    // Create uploads directory if it doesn't exist
    if (!fs.existsSync("uploads")) {
      fs.mkdirSync("uploads")
      console.log("Created uploads directory")
    }
  } catch (error) {
    console.error("Database initialization error:", error)
    process.exit(1)
  }
}

// Image upload setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/")
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`)
  },
})

const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) {
      cb(null, true)
    } else {
      cb(new Error("Only image files are allowed!"), false)
    }
  },
})

// Helper function to execute SQL queries
async function query(sql, params) {
  const [rows] = await pool.execute(sql, params)
  return rows
}

// Authentication middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) return res.sendStatus(401)

  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET || "your-secret-key", (err, user) => {
    if (err) return res.sendStatus(403)
    req.user = user
    next()
  })
}

// Routes

// User registration
app.post("/api/register", async (req, res) => {
  try {
    const { username, email, password } = req.body

    // Check if user exists
    const existingUser = await query("SELECT * FROM users WHERE username = ? OR email = ?", [username, email])
    if (existingUser.length > 0) {
      return res.status(400).json({ error: "Username or email already exists" })
    }

    // Hash password
    const salt = await bcrypt.genSalt(10)
    const passwordHash = await bcrypt.hash(password, salt)

    // Create user
    const result = await query("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)", [
      username,
      email,
      passwordHash,
    ])

    res.status(201).json({ message: "User registered successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// User login
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Find user
    const [user] = await query("SELECT * FROM users WHERE email = ?", [email])
    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password_hash)
    if (!validPassword) {
      return res.status(401).json({ error: "Invalid credentials" })
    }

    // Generate JWT token with longer expiration (7 days)
    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email },
      process.env.ACCESS_TOKEN_SECRET || "your-secret-key",
      { expiresIn: "2m" }, // Changed from 24h to 7 days
    )

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        profile_picture: user.profile_picture,
      },
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})


// Ping endpoint to keep session alive
app.get("/api/ping", authenticateToken, (req, res) => {
  res.json({ message: "Pong", userId: req.user.id })
})

// Get current user profile
app.get("/api/users/me", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const [user] = await query("SELECT id, username, email, profile_picture, created_at FROM users WHERE id = ?", [
      userId,
    ])

    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    res.json(user)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get user profile
app.get("/api/users/:id", authenticateToken, async (req, res) => {
  try {
    const userId = req.params.id
    const [user] = await query("SELECT id, username, email, profile_picture, created_at FROM users WHERE id = ?", [
      userId,
    ])

    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    res.json(user)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Update user profile
app.put("/api/users/:id", authenticateToken, upload.single("profile_picture"), async (req, res) => {
  try {
    const userId = req.params.id

    // Check if user is updating their own profile
    if (Number.parseInt(userId) !== req.user.id) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    const { username, email } = req.body
    let profilePicture = null

    // Check if username or email already exists
    const [existingUser] = await query("SELECT * FROM users WHERE (username = ? OR email = ?) AND id != ?", [
      username,
      email,
      userId,
    ])

    if (existingUser) {
      return res.status(400).json({ error: "Username or email already exists" })
    }

    // Handle profile picture upload
    if (req.file) {
      profilePicture = req.file.filename

      // Delete old profile picture if it exists and isn't the default
      const [user] = await query("SELECT profile_picture FROM users WHERE id = ?", [userId])
      if (user.profile_picture && user.profile_picture !== "default.jpg") {
        try {
          fs.unlinkSync(path.join(__dirname, "uploads", user.profile_picture))
        } catch (err) {
          console.error("Error deleting old profile picture:", err)
        }
      }
    }

    // Update user
    const updateFields = []
    const updateValues = []

    if (username) {
      updateFields.push("username = ?")
      updateValues.push(username)
    }

    if (email) {
      updateFields.push("email = ?")
      updateValues.push(email)
    }

    if (profilePicture) {
      updateFields.push("profile_picture = ?")
      updateValues.push(profilePicture)
    }

    if (updateFields.length > 0) {
      updateValues.push(userId)
      await query(`UPDATE users SET ${updateFields.join(", ")} WHERE id = ?`, updateValues)
    }

    res.json({ message: "Profile updated successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Questions CRUD

// Create question
app.post("/api/questions", authenticateToken, upload.single("image"), async (req, res) => {
  try {
    const { title, body, topic } = req.body
    const userId = req.user.id
    let imageUrl = null

    if (req.file) {
      imageUrl = req.file.filename
    }

    const result = await query(
      "INSERT INTO questions (user_id, title, body, topic, image_url) VALUES (?, ?, ?, ?, ?)",
      [userId, title, body, topic, imageUrl],
    )

    const [question] = await query("SELECT * FROM questions WHERE id = ?", [result.insertId])

    res.status(201).json(question)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Update the GET questions endpoint to handle empty results better
// Get all questions
app.get("/api/questions", async (req, res) => {
  try {
    const { topic, search, sort = "newest" } = req.query

    let sql = `
      SELECT q.*, u.username, u.profile_picture, 
      (SELECT COUNT(*) FROM answers a WHERE a.question_id = q.id) as answer_count
      FROM questions q
      JOIN users u ON q.user_id = u.id
    `
    const params = []

    // Apply filters
    if (topic) {
      sql += " WHERE q.topic = ?"
      params.push(topic)
    }

    if (search) {
      sql += topic ? " AND" : " WHERE"
      sql += " (q.title LIKE ? OR q.body LIKE ?)"
      params.push(`%${search}%`, `%${search}%`)
    }

    // Apply sorting
    switch (sort) {
      case "newest":
        sql += " ORDER BY q.created_at DESC"
        break
      case "oldest":
        sql += " ORDER BY q.created_at ASC"
        break
      case "popular":
        sql += " ORDER BY (q.upvotes - q.downvotes) DESC"
        break
      case "controversial":
        sql += " ORDER BY (q.upvotes + q.downvotes) DESC"
        break
    }

    try {
      const questions = await query(sql, params)
      res.json(questions)
    } catch (error) {
      // If there's an error with the query, check if it's because the table doesn't exist
      console.error("Error querying questions:", error)

      // Return an empty array instead of an error
      res.json([])
    }
  } catch (error) {
    console.error("Error in questions endpoint:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get single question
app.get("/api/questions/:id", async (req, res) => {
  try {
    const questionId = req.params.id

    const [question] = await query(
      `
      SELECT q.*, u.username, u.profile_picture 
      FROM questions q
      JOIN users u ON q.user_id = u.id
      WHERE q.id = ?
    `,
      [questionId],
    )

    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    // Get answers for this question
    const answers = await query(
      `
      SELECT a.*, u.username, u.profile_picture
      FROM answers a
      JOIN users u ON a.user_id = u.id
      WHERE a.question_id = ?
      ORDER BY a.is_accepted DESC, (a.upvotes - a.downvotes) DESC
    `,
      [questionId],
    )

    // Get comments for this question
    const questionComments = await query(
      `
      SELECT c.*, u.username, u.profile_picture
      FROM comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.content_type = 'question' AND c.content_id = ?
      ORDER BY c.created_at ASC
    `,
      [questionId],
    )

    // Add comments to answers
    const answersWithComments = await Promise.all(
      answers.map(async (answer) => {
        const comments = await query(
          `
        SELECT c.*, u.username, u.profile_picture
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.content_type = 'answer' AND c.content_id = ?
        ORDER BY c.created_at ASC
      `,
          [answer.id],
        )

        return { ...answer, comments }
      }),
    )

    res.json({
      ...question,
      answers: answersWithComments,
      comments: questionComments,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Update question
app.put("/api/questions/:id", authenticateToken, upload.single("image"), async (req, res) => {
  try {
    const questionId = req.params.id
    const { title, body, topic } = req.body
    const userId = req.user.id

    // Check if question exists and belongs to user
    const [question] = await query("SELECT * FROM questions WHERE id = ?", [questionId])
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    if (question.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    let imageUrl = question.image_url

    // Handle image update
    if (req.file) {
      imageUrl = req.file.filename

      // Delete old image if it exists
      if (question.image_url) {
        try {
          fs.unlinkSync(path.join(__dirname, "uploads", question.image_url))
        } catch (err) {
          console.error("Error deleting old image:", err)
        }
      }
    }

    // Update question
    await query("UPDATE questions SET title = ?, body = ?, topic = ?, image_url = ? WHERE id = ?", [
      title,
      body,
      topic,
      imageUrl,
      questionId,
    ])

    const [updatedQuestion] = await query("SELECT * FROM questions WHERE id = ?", [questionId])
    res.json(updatedQuestion)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Delete question
app.delete("/api/questions/:id", authenticateToken, async (req, res) => {
  try {
    const questionId = req.params.id
    const userId = req.user.id

    // Check if question exists and belongs to user
    const [question] = await query("SELECT * FROM questions WHERE id = ?", [questionId])
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    if (question.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    // Delete image if it exists
    if (question.image_url) {
      try {
        fs.unlinkSync(path.join(__dirname, "uploads", question.image_url))
      } catch (err) {
        console.error("Error deleting image:", err)
      }
    }

    // Delete question (foreign key constraints will handle related answers/comments)
    await query("DELETE FROM questions WHERE id = ?", [questionId])

    res.json({ message: "Question deleted successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Answers CRUD

// Create answer
app.post("/api/questions/:id/answers", authenticateToken, async (req, res) => {
  try {
    const questionId = req.params.id
    const { body } = req.body
    const userId = req.user.id

    // Check if question exists
    const [question] = await query("SELECT * FROM questions WHERE id = ?", [questionId])
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    const result = await query("INSERT INTO answers (question_id, user_id, body) VALUES (?, ?, ?)", [
      questionId,
      userId,
      body,
    ])

    const [answer] = await query("SELECT * FROM answers WHERE id = ?", [result.insertId])
    res.status(201).json(answer)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Update answer
app.put("/api/answers/:id", authenticateToken, async (req, res) => {
  try {
    const answerId = req.params.id
    const { body } = req.body
    const userId = req.user.id

    // Check if answer exists and belongs to user
    const [answer] = await query("SELECT * FROM answers WHERE id = ?", [answerId])
    if (!answer) {
      return res.status(404).json({ error: "Answer not found" })
    }

    if (answer.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    await query("UPDATE answers SET body = ? WHERE id = ?", [body, answerId])

    const [updatedAnswer] = await query("SELECT * FROM answers WHERE id = ?", [answerId])
    res.json(updatedAnswer)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Delete answer
app.delete("/api/answers/:id", authenticateToken, async (req, res) => {
  try {
    const answerId = req.params.id
    const userId = req.user.id

    // Check if answer exists and belongs to user
    const [answer] = await query("SELECT * FROM answers WHERE id = ?", [answerId])
    if (!answer) {
      return res.status(404).json({ error: "Answer not found" })
    }

    if (answer.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    await query("DELETE FROM answers WHERE id = ?", [answerId])
    res.json({ message: "Answer deleted successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Accept answer
app.post("/api/answers/:id/accept", authenticateToken, async (req, res) => {
  try {
    const answerId = req.params.id
    const userId = req.user.id

    // Check if answer exists
    const [answer] = await query("SELECT * FROM answers WHERE id = ?", [answerId])
    if (!answer) {
      return res.status(404).json({ error: "Answer not found" })
    }

    // Check if user is the question owner
    const [question] = await query("SELECT * FROM questions WHERE id = ?", [answer.question_id])
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    if (question.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    // Unaccept any previously accepted answer for this question
    await query("UPDATE answers SET is_accepted = FALSE WHERE question_id = ? AND is_accepted = TRUE", [
      answer.question_id,
    ])

    // Accept this answer
    await query("UPDATE answers SET is_accepted = TRUE WHERE id = ?", [answerId])

    res.json({ message: "Answer accepted successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Comments CRUD

// Create comment
app.post("/api/comments", authenticateToken, async (req, res) => {
  try {
    const { content_type, content_id, body } = req.body
    const userId = req.user.id

    // Validate content type
    if (content_type !== "question" && content_type !== "answer") {
      return res.status(400).json({ error: "Invalid content type" })
    }

    // Check if content exists
    let contentExists
    if (content_type === "question") {
      ;[contentExists] = await query("SELECT id FROM questions WHERE id = ?", [content_id])
    } else {
      ;[contentExists] = await query("SELECT id FROM answers WHERE id = ?", [content_id])
    }

    if (!contentExists) {
      return res.status(404).json({ error: "Content not found" })
    }

    const result = await query("INSERT INTO comments (content_type, content_id, user_id, body) VALUES (?, ?, ?, ?)", [
      content_type,
      content_id,
      userId,
      body,
    ])

    const [comment] = await query(
      `
      SELECT c.*, u.username, u.profile_picture 
      FROM comments c
      JOIN users u ON c.user_id = u.id
      WHERE c.id = ?
    `,
      [result.insertId],
    )

    res.status(201).json(comment)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Delete comment
app.delete("/api/comments/:id", authenticateToken, async (req, res) => {
  try {
    const commentId = req.params.id
    const userId = req.user.id

    // Check if comment exists and belongs to user
    const [comment] = await query("SELECT * FROM comments WHERE id = ?", [commentId])
    if (!comment) {
      return res.status(404).json({ error: "Comment not found" })
    }

    if (comment.user_id !== userId) {
      return res.status(403).json({ error: "Unauthorized" })
    }

    await query("DELETE FROM comments WHERE id = ?", [commentId])
    res.json({ message: "Comment deleted successfully" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Voting

// Vote on content
app.post("/api/vote", authenticateToken, async (req, res) => {
  try {
    const { content_type, content_id, vote_type } = req.body
    const userId = req.user.id

    // Validate content type
    if (content_type !== "question" && content_type !== "answer") {
      return res.status(400).json({ error: "Invalid content type" })
    }

    // Validate vote type
    if (vote_type !== "upvote" && vote_type !== "downvote") {
      return res.status(400).json({ error: "Invalid vote type" })
    }

    // Check if content exists
    let contentExists
    if (content_type === "question") {
      ;[contentExists] = await query("SELECT id FROM questions WHERE id = ?", [content_id])
    } else {
      ;[contentExists] = await query("SELECT id FROM answers WHERE id = ?", [content_id])
    }

    if (!contentExists) {
      return res.status(404).json({ error: "Content not found" })
    }

    // Check if user already voted
    const [existingVote] = await query(
      "SELECT * FROM votes WHERE user_id = ? AND content_type = ? AND content_id = ?",
      [userId, content_type, content_id],
    )

    const table = content_type === "question" ? "questions" : "answers"

    if (existingVote) {
      if (existingVote.vote_type === vote_type) {
        // Remove vote if same type clicked again
        await query("DELETE FROM votes WHERE id = ?", [existingVote.id])

        // Update content vote count
        await query(`UPDATE ${table} SET ${vote_type}s = ${vote_type}s - 1 WHERE id = ?`, [content_id])
      } else {
        // Change vote type
        await query("UPDATE votes SET vote_type = ? WHERE id = ?", [vote_type, existingVote.id])

        // Update content vote counts
        const oldVoteType = existingVote.vote_type
        await query(
          `UPDATE ${table} SET ${oldVoteType}s = ${oldVoteType}s - 1, ${vote_type}s = ${vote_type}s + 1 WHERE id = ?`,
          [content_id],
        )
      }
    } else {
      // Add new vote
      await query("INSERT INTO votes (user_id, content_type, content_id, vote_type) VALUES (?, ?, ?, ?)", [
        userId,
        content_type,
        content_id,
        vote_type,
      ])

      // Update content vote count
      await query(`UPDATE ${table} SET ${vote_type}s = ${vote_type}s + 1 WHERE id = ?`, [content_id])
    }

    // Get updated vote counts
    const [content] = await query(`SELECT upvotes, downvotes FROM ${table} WHERE id = ?`, [content_id])

    res.json({
      upvotes: content.upvotes,
      downvotes: content.downvotes,
      user_vote: existingVote && existingVote.vote_type === vote_type ? null : vote_type,
    })
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Topics

// Get all topics
app.get("/api/topics", async (req, res) => {
  try {
    const topics = await query("SELECT DISTINCT topic FROM questions ORDER BY topic ASC")
    res.json(topics.map((t) => t.topic))
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Get popular topics
app.get("/api/topics/popular", async (req, res) => {
  try {
    const topics = await query(`
      SELECT topic, COUNT(*) as question_count 
      FROM questions 
      GROUP BY topic 
      ORDER BY question_count DESC 
      LIMIT 10
    `)
    res.json(topics)
  } catch (error) {
    console.error(error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Start server
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`)
  // Initialize database on server start
  await initializeDatabase()
})

